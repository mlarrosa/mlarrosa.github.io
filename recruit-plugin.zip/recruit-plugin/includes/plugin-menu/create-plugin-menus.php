<?php

    function CreatePluginMenus() {
        add_menu_page(
            'Recruit Plugin Main Page', // Page Title
            'Recuit', // Page name on Menu
            'manage_options', // Capability
            'recruit-settings', // Slug del menu
            'pluginPageHTML', // Funcion Callback, llama a la funcion que imprime el HTML de la pagina del plugin
            'dashicons-admin-plugins', // Dashicon de la opcion del menu
            '1'// Prioridad que tiene en el menu (aparecer mas arriba o mas abajo en el menu)
        );
        add_submenu_page( 'recruit-settings', 'Settings', 'Settings', 'manage_options', 'recruit-settings&tab=settings', 'settingsHTML');
        add_submenu_page( 'recruit-settings', 'Shortcodes', 'Shortcodes', 'manage_options', 'recruit-settings&tab=shortcodes', 'shortcodesHTML');

    }
    add_action('admin_menu', 'CreatePluginMenus');




    function pluginPageHTML() {
        require_once plugin_dir_path(__FILE__) . '/plugin_settings_page_html.php';
    }
    


?>