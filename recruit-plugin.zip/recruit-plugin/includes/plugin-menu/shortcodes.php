<?php
    $dashboard_page_id = get_page_by_path( 'dashboard' )->ID;
    $interviews_page_id = get_page_by_path( 'interviews' )->ID;
    $newcandidate_page_id = get_page_by_path( 'newcandidate' )->ID;

?>

<h1>Shortcodes</h1>


    <table class="form-table">
        <tr>
            <td>Copy the Shortcode <strong> [dashboard] </strong> and add it to the <a href="<?php echo get_edit_post_link($dashboard_page_id);?>">Dashboard page</a></td>
        </tr>
        <tr>
            <td>Copy the Shortcode <strong> [interviews] </strong> and add it to the <a href="<?php echo get_edit_post_link($interviews_page_id);?>">Interviews page</a></td>
        </tr>
        <tr>
            <td>Copy the Shortcode <strong> [newcandidate] </strong> and add it to the <a href="<?php echo get_edit_post_link($newcandidate_page_id);?>">New candidate page</a></td>
        </tr>
    </table>


<?php

?>