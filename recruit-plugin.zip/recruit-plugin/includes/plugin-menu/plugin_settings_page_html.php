<?php 

  // check user capabilities
  if ( ! current_user_can( 'manage_options' ) ) {
    return;
  }

  //Get the active tab from the $_GET param
  $default_tab = null;
  $tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;

  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <!-- Here are our tabs -->
    <nav class="nav-tab-wrapper">
      <a href="?page=recruit-settings&tab=shortcodes" class="nav-tab <?php if($tab==='shortcodes'):?>nav-tab-active<?php endif; ?>">Shortcodes</a>
      <a href="?page=recruit-settings&tab=settings" class="nav-tab <?php if($tab==='settings'):?>nav-tab-active<?php endif; ?>">Settings</a>
    </nav>

    <div class="tab-content">
        <div class="wrap">
            <?php switch($tab) :
            case 'shortcodes':
                require 'shortcodes.php';
                break;
            case 'settings':
                require 'settings.php';
                break;
            case 'interviews':
                require 'interviews.php';
                break;
            endswitch; ?>
            </div>
        </div>
    </div>