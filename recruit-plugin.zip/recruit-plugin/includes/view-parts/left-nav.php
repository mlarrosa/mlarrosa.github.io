<div style="background-position:-200px top;background-size:cover;background-image:url('<?php echo site_url() .'/wp-content/uploads/user-people-network-circuit-board2.png';?>');" class="left-side" :class="{'active' : leftSide}">

  <div class="left-side-button" @click="leftSide = !leftSide">
      <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
          <svg stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
          <path d="M19 12H5M12 19l-7-7 7-7"/>
      </svg>
  </div>

  <a href="<?php echo site_url() .'/dashboard';?>">
    <div class="logo">
      <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/recru-it-logo-blanco.png'; ?>" alt="logo">
    </div>
  </a>

  <div class="side-wrapper">

    <div class="side-menu">
      <a href="<?php echo site_url().'/dashboard';?>">
        <i class="fa fa-user" style="font-size:23px;margin-right:10px;"></i>
        Candidates
      </a>
      <a id="scheduled-interviews" href="<?php echo site_url() .'/interviews';?>">
          <i class="fa fa-clock-o" style="font-size:23px;margin-right:10px;"></i> Scheduled Interviews

          <?php         
            $args = array(
              'post_type' => 'candidates',
              'meta_query' => array(
                  array (
                      'key'     => 'recruit_interview_date',
                      'compare' => '!=',
                      'value' => NULL,
                  ),
              ),
          );

            $candidates_interview_scheduled = new WP_Query( $args );          
              if( $candidates_interview_scheduled->have_posts() ) :
          ?>
            <span>
              <?php echo $candidates_interview_scheduled->found_posts;?>
            </span>
          <?php endif; ?>
        </a>
    </div>

  </div>

  <div class="side-wrapper">
    <h4 class="side-title">BEST CANDIDATES</h4>

    <div id="best-candidates">

      <?php 
          $args = array(
            'post_type' => 'candidates',
            'meta_query' => array(
              array (
                  'key'     => 'recruit_best',
                  'value'   => "Yes",
                  'compare' => '=',
                ),
            ),
          );
          $best_candidates = new WP_Query( $args );

          if( $best_candidates->have_posts() ) :
            while( $best_candidates->have_posts() ) : $best_candidates->the_post(); 
        ?>

          <a href="<?php the_permalink();?>">
            <div class="best-candidate">
              <img src="<?php echo get_the_post_thumbnail_url();?>" alt="" class="best-candidate-img">
              <div class="username">
                <?php echo get_post_meta( get_the_ID(), 'recruit_fullname', true);?>
                <div class="position">
                  <?php echo get_post_meta( get_the_ID(), 'recruit_position', true);?>
                </div>
              </div>
            </div>
          </a>

      <?php
            endwhile;
          endif;
      ?>

    </div>

  </div>

</div>
  
