<?php


/*
* Creating a function to create our CPT
*/
  
function recruit_candidates_post_type() {
  
    // Set UI labels for Custom Post Type
        $labels = array(
            'name'                => _x( 'Candidates', 'Post Type General Name', 'twentytwentyone' ),
            'singular_name'       => _x( 'Candidate', 'Post Type Singular Name', 'twentytwentyone' ),
            'menu_name'           => __( 'Candidates', 'twentytwentyone' ),
            'parent_item_colon'   => __( 'Parent Candidate', 'twentytwentyone' ),
            'all_items'           => __( 'All Candidates', 'twentytwentyone' ),
            'view_item'           => __( 'View Candidate', 'twentytwentyone' ),
            'add_new_item'        => __( 'Add New Candidate', 'twentytwentyone' ),
            'add_new'             => __( 'Add New', 'twentytwentyone' ),
            'edit_item'           => __( 'Edit Candidate', 'twentytwentyone' ),
            'update_item'         => __( 'Update Candidate', 'twentytwentyone' ),
            'search_items'        => __( 'Search Candidate', 'twentytwentyone' ),
            'not_found'           => __( 'Not Found', 'twentytwentyone' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwentyone' ),
        );
          
    // Set other options for Custom Post Type
          
        $args = array(
            'label'               => __( 'Candidates', 'twentytwentyone' ),
            'description'         => __( 'Candidate news and reviews', 'twentytwentyone' ),
            'labels'              => $labels,
            // Features this CPT supports in Post Editor
            'supports'            => array( 'title', 'thumbnail' ),
            // You can associate this CPT with a taxonomy or custom taxonomy. 
            /* A hierarchical CPT is like Pages and can have
            * Parent and child items. A non-hierarchical CPT
            * is like Posts.
            */
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
            'show_in_rest' => true,
            'menu_icon'           => 'dashicons-admin-users',
      
        );
          
        // Registering your Custom Post Type
        register_post_type( 'Candidates', $args );
      
    }
      
    /* Hook into the 'init' action so that the function
    * Containing our post type registration is not 
    * unnecessarily executed. 
    */
      
    add_action( 'init', 'recruit_candidates_post_type' );

?>