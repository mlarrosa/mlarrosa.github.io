<?php

    if(!defined('ABSPATH')) exit;

    function recruit_add_metaboxes() {

        //Agrega el metabox al custom post type Candidates
        add_meta_box('candidate_metaboxes', 'Candidate Information', 'candidates_metaboxes_html', 'candidates', 'normal', 'high', null);

    }

    add_action('add_meta_boxes', 'recruit_add_metaboxes');


    function candidates_metaboxes_html($post) { ?>
        
        <table class="form-table">
            <tr>
                <th class="row-title">
                    <label for="fullname">Full Name: </label>
                </th>
                <td>
                    <input id="fullname" value="<?php echo get_post_meta($post->ID, 'recruit_fullname', true);?>" name="recruit_fullname" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="position">Position: </label>
                </th>
                <td>
                    <input id="position" value="<?php echo get_post_meta($post->ID, 'recruit_position', true);?>" name="recruit_position" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="resume">Resume: </label>
                </th>
                <td>
                    <input id="resume" value="<?php echo get_post_meta($post->ID, 'recruit_resume_url', true);?>" name="recruit_resume_url" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="email">Email: </label>
                </th>
                <td>
                    <input id="email" value="<?php echo get_post_meta($post->ID, 'recruit_email', true);?>" name="recruit_email" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="skype">Skype: </label>
                </th>
                <td>
                    <input id="skype" value="<?php echo get_post_meta($post->ID, 'recruit_skype', true);?>" name="recruit_skype" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="mobile">Mobile: </label>
                </th>
                <td>
                    <input id="mobile" value="<?php echo get_post_meta($post->ID, 'recruit_mobile', true);?>" name="recruit_mobile" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="portfolio_url">Portfolio URL: </label>
                </th>
                <td>
                    <input id="portfolio_url" value="<?php echo get_post_meta($post->ID, 'recruit_portfolio_url', true);?>" name="recruit_portfolio_url" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="github_url">Github URL: </label>
                </th>
                <td>
                    <input id="github_url" value="<?php echo get_post_meta($post->ID, 'recruit_github_url', true);?>" name="recruit_github_url" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="behance_url">Behance URL: </label>
                </th>
                <td>
                    <input id="behance_url" value="<?php echo get_post_meta($post->ID, 'recruit_behance_url', true);?>" name="recruit_behance_url" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="recruit_notes">Notes: </label>
                </th>
                <td>
                    <input id="recruit_notes" value="<?php echo get_post_meta($post->ID, 'recruit_notes', true);?>" name="recruit_notes" class="regular-text" type="text">
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="recruit_best">Best Candidate?: </label>
                </th>
                <td>
                    <?php $is_best = get_post_meta($post->ID, 'recruit_best', true); ?>
                    <select id="recruit_best" name="recruit_best">
                        <option <?php selected($is_best, 'No')?> value="No">No</option>
                        <option <?php selected($is_best, 'Yes')?> value="Yes">Yes</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th class="row-title">
                    <label for="recruit_best">Scheduled Interview Date: </label>
                </th>
                <td>
                    <input id="recruit_interview_date" value="<?php echo get_post_meta($post->ID, 'recruit_interview_date', true);?>" name="recruit_interview_date" class="regular-text" type="text">
                </td>
            </tr>
        </table>

   <?php } 
   // End function candidates_metaboxes_html

        function recruit_save_metaboxes( $post_id, $post, $update ) {

            $recruit_interview_date_value = $recruit_fullname_value = $recruit_position_value = $recruit_resume_url_value = $recruit_email_value = $recruit_mobile_value = $recruit_skype_value = $recruit_portfolio_url_value = $recruit_notes_value = $recruit_github_url_value = $recruit_behance_url_value = $recruit_best_value ='';

            if( isset( $_POST['recruit_fullname'] ) ) {
                $recruit_fullname_value = sanitize_text_field( $_POST['recruit_fullname'] );
            }
            update_post_meta($post_id, 'recruit_fullname', $recruit_fullname_value);

            if( isset( $_POST['recruit_position'] ) ) {
                $recruit_position_value = sanitize_text_field( $_POST['recruit_position'] );
            }
            update_post_meta($post_id, 'recruit_position', $recruit_position_value);

            
            if( isset( $_POST['recruit_resume_url'] ) ) {
                $recruit_resume_url_value = sanitize_text_field( $_POST['recruit_resume_url'] );
            }
            update_post_meta($post_id, 'recruit_resume_url', $recruit_resume_url_value);

            
            if( isset( $_POST['recruit_email'] ) ) {
                $recruit_email_value = sanitize_text_field( $_POST['recruit_email'] );
            }
            update_post_meta($post_id, 'recruit_email', $recruit_email_value);

            
            if( isset( $_POST['recruit_mobile'] ) ) {
                $recruit_mobile_value = sanitize_text_field( $_POST['recruit_mobile'] );
            }
            update_post_meta($post_id, 'recruit_mobile', $recruit_mobile_value);


            if( isset( $_POST['recruit_skype'] ) ) {
                $recruit_skype_value = sanitize_text_field( $_POST['recruit_skype'] );
            }
            update_post_meta($post_id, 'recruit_skype', $recruit_skype_value);


            if( isset( $_POST['recruit_portfolio_url'] ) ) {
                $recruit_portfolio_url_value = sanitize_text_field( $_POST['recruit_portfolio_url'] );
            }
            update_post_meta($post_id, 'recruit_portfolio_url', $recruit_portfolio_url_value);


            if( isset( $_POST['recruit_notes'] ) ) {
                $recruit_notes_value = sanitize_text_field( $_POST['recruit_notes'] );
            }
            update_post_meta($post_id, 'recruit_notes', $recruit_notes_value);


            if( isset( $_POST['recruit_github_url'] ) ) {
                $recruit_github_url_value = sanitize_text_field( $_POST['recruit_github_url'] );
            }
            update_post_meta($post_id, 'recruit_github_url', $recruit_github_url_value);


            if( isset( $_POST['recruit_behance_url'] ) ) {
                $recruit_behance_url_value = sanitize_text_field( $_POST['recruit_behance_url'] );
            }
            update_post_meta($post_id, 'recruit_behance_url', $recruit_behance_url_value);


            if( isset( $_POST['recruit_best'] ) ) {
                $recruit_best_value = $_POST['recruit_best'];
            }
            update_post_meta($post_id, 'recruit_best', $recruit_best_value);


            if( isset( $_POST['recruit_interview_date'] ) ) {
                $recruit_interview_date_value = $_POST['recruit_interview_date'];
            }
            update_post_meta($post_id, 'recruit_interview_date', $recruit_interview_date_value);


        }

        add_action('save_post', 'recruit_save_metaboxes', 10, 3);

?>