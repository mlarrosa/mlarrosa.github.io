<?php
  wp_head();
?>



<style>
    .wp-site-blocks {display:none;}
</style>



<div class="modalbox error col-sm-8 col-md-6 col-lg-5 center animate">
  <div class="icon">
    <span class="fa fa-check"></span>
  </div>
  <!--/.icon-->
  <h1>Success!</h1>
  <p>The candidate has been deleted</p>
</div>


<div id="dashboard-page" class="container">

  <?php include_once plugin_dir_path(__FILE__) . 'includes/view-parts/left-nav.php'; ?>
  
  <div class="main">
    <div class="main-container">


      <a id="add-new-candidate-button" href="<?php echo site_url().'/newcandidate';?>">
        <i id="add-candidate-plus" class="fa fa-plus"></i>
        <span>Add New Candidate</span>
      </a>


      <div class="search-bar">
        <input type="text" placeholder="Search for a position or candidate" />
        <button class="right-side-button" @click="rightSide = !rightSide">
           <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </button>
      </div>


      
      <div id="candidates-grid">

        <?php 
          $args = array(
            'post_type' => 'candidates'
          );

          $candidates = new WP_Query($args);

          if( $candidates-> have_posts() ) :
            while( $candidates-> have_posts() ) : $candidates->the_post();
        ?>
          
            <div class="card-container">
              <a href="<?php the_permalink();?>">
                <div class="text-center card-box">
                  <div class="candidate-card pt-2 pb-2 <?php echo(get_post_meta(get_the_ID(), 'recruit_interview_date', true)) ? 'inteview-badge' : '';?>">
                    <div class="thumb-lg member-thumb mx-auto">
                      <img src="<?php echo get_the_post_thumbnail_url(get_the_ID());?>" class="rounded-circle img-thumbnail" alt="profile-image">
                    </div>
                    <div class="">
                        <h4 class="candidate-name"><?php the_title();?></h4>
                        <p class="text-muted"> <span>| </span><span><a href="#" class="text-pink"><?php echo get_post_meta(get_the_ID(), 'recruit_portfolio_url', true);?></a></span></p>
                    </div>
                    <a href="<?php the_permalink();?>" type="button" class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">See Profile</a>
                    <ul class="social-links list-inline">
                      <li class="list-inline-item">
                        <a title="" data-placement="top" data-toggle="tooltip" class="tooltips" target="_blank" href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=<?php echo get_post_meta(get_the_ID(), 'recruit_email', true);?>" data-original-title="Facebook">
                          <i class="fa fa-envelope"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a title="" data-placement="top" data-toggle="tooltip" class="tooltips" href="" data-original-title="Skype">
                          <i class="fa fa-skype"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </a>
            </div>
            
            <?php 
              wp_reset_postdata();
              endwhile; 
            ?>
          <?php else: ?>
            <?php echo "<span style='color:#000'> Add your first candidate ! </span>" ?>
          <?php endif; ?>

      </div>

    </div>
  </div>  

</div>
          