
jQuery("#add-as-best-candidate-button").on('click', function(e) {
    e.preventDefault();

    const id_post = jQuery("#profile-container").attr("class").replace(/^.*post-/,'');

    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'add_best_candidate',
            id_candidate: id_post
        },
        success:function(response){
            jQuery("#add-as-best-candidate-button").css("display", "none");
            jQuery("#remove-as-best-candidate-button").css("display", "block");
            location.reload();
            location.reload();
            location.reload();
        }
    });

});




jQuery("#remove-as-best-candidate-button").on('click', function(e) {
    e.preventDefault();

    const id_post = jQuery("#profile-container").attr("class").replace(/^.*post-/,'');

    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'remove_best_candidate',
            id_candidate: id_post
        },
        success:function(response){
            jQuery("#add-as-best-candidate-button").css("display", "block");
            jQuery("#remove-as-best-candidate-button").css("display", "none");
            location.reload();
            location.reload();
            location.reload();
        }
    });

});



jQuery("#delete-candidate-button").on('click', function(e) {
    e.preventDefault();


    const id_post = jQuery("#profile-container").attr("class").replace(/^.*post-/,'');

    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'delete_candidate',
            id_candidate: id_post
        },
        success:function(response){
            window.location.href = response;
            
        }
    });

    jQuery(".modalbox.succes").css('display','block');
    jQuery(".modal-confirm .modal-header, .modal-confirm .modal-body, .modal-confirm .modal-footer").css('display','none');
    
});






jQuery("#edit-candidate-button").on('click', function(e) {
    e.preventDefault();

    const id_post = jQuery("#profile-container").attr("class").replace(/^.*post-/,'');

    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'edit_candidate',
            id_candidate: id_post
        },
        success:function(response){
            jQuery(".editing-field").css("display", "block");
            jQuery(".displayed-field").css("display", "none");
            jQuery("#update-candidate-button").css("display", "inline-block");
            jQuery("#edit-candidate-button").css("display", "none");
            jQuery("#confirmed-date-text").css("display", "none");
        }
    });

});






jQuery(".cancel-interview-button").on('click', function(e) {
    e.preventDefault();

    var candidate_clicked_id = jQuery(e.target).closest(".users").attr("class").replace(/^.*user-/,'');
    
    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'cancel_interview',
            id_candidate: candidate_clicked_id
        },
        success:function(response){
            location.reload();
            location.reload();
            location.reload();
        }
    });

});








jQuery("#update-candidate-button").on('click', function(e) {
    e.preventDefault();

    const id_post = jQuery("#profile-container").attr("class").replace(/^.*post-/,'');

    var fullname = jQuery("#fullname").val();
    var portfolio_url = jQuery("#portfolio_url").val();
    var github_url = jQuery("#github_url").val();
    var behance_url = jQuery("#behance_url").val();
    var position = jQuery("#position").val();
    var resume = jQuery("#resume").val();
    var email = jQuery("#email").val();
    var skype = jQuery("#skype").val();
    var mobile = jQuery("#mobile").val();
    var notes = jQuery("#recruit_notes").val();


    var interview_date = jQuery("#recruit_interview_date ").val();

    if(interview_date == '') {
        interview_date = jQuery("#confirmed-date-text #printed-text").text();
    }


    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'update_candidate',
            id_candidate: id_post,
            candidate_fullname: fullname,
            candidate_portfolio_url: portfolio_url,
            candidate_github_url: github_url,
            candidate_behance_url: behance_url,
            candidate_position: position,
            candidate_resume: resume,
            candidate_email: email,
            candidate_skype: skype,
            candidate_mobile: mobile,
            candidate_recruit_notes: notes,
            candidate_interview_date: interview_date
        },
        success:function(response){
            jQuery(".editing-field").css("display", "none");
            jQuery(".displayed-field").css("display", "block");
            jQuery("#update-candidate-button").css("display", "inline-block");
            jQuery("#edit-candidate-button").css("display", "none");
            jQuery("#confirmed-date-text").css("display", "none");
            location.reload();
            location.reload();
            location.reload();
        }
    });

});







/*

jQuery("#add-candidate-button").on('click', function(e) {
    e.preventDefault();

    var fullname = jQuery("#fullname").val();
    var portfolio_url = jQuery("#portfolio_url").val();
    var github_url = jQuery("#github_url").val();
    var behance_url = jQuery("#behance_url").val();
    var position = jQuery("#position").val();
    var resume = jQuery("#resume").val();
    var email = jQuery("#email").val();
    var skype = jQuery("#skype").val();
    var mobile = jQuery("#mobile").val();
    var notes = jQuery("#recruit_notes").val();
    var interview_date = jQuery("#recruit_interview_date ").val();

    if(interview_date == '') {
        interview_date = jQuery("#confirmed-date-text #printed-text").text();
    }

    var image_upload = jQuery("#imageUpload ").val();
    console.log(image_upload);
    

    

    jQuery.ajax({
        type: 'GET',
        cache: 'false',
        url: recruit_vars.ajaxurl,
        data:{
            action: 'add_new_candidate',
            candidate_fullname: fullname,
            candidate_portfolio_url: portfolio_url,
            candidate_github_url: github_url,
            candidate_behance_url: behance_url,
            candidate_position: position,
            candidate_resume: resume,
            candidate_email: email,
            candidate_skype: skype,
            candidate_mobile: mobile,
            candidate_recruit_notes: notes,
            candidate_interview_date: interview_date
        },
        success:function(response){
            jQuery(".editing-field").css("display", "none");
            jQuery(".displayed-field").css("display", "block");
            jQuery("#update-candidate-button").css("display", "inline-block");
            jQuery("#edit-candidate-button").css("display", "none");
            jQuery("#confirmed-date-text").css("display", "none");
            location.reload();
            location.reload();
            location.reload();
        }
    });

});
*/










//Search Filter
jQuery(document).ready(function() {
    jQuery(".search-bar input").on("keyup", function() {
        var value = jQuery(this).val().toLowerCase();
        jQuery("#candidates-grid .card-container").filter(function() {
        jQuery(this).toggle(jQuery(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});








let simplepicker = new SimplePicker({
    zIndex: 10
});

jQuery("#schedule-interview-button").on('click', function(){

    simplepicker.open();

    const $button = document.querySelector('button');
    const $eventLog = document.querySelector('.event-log');
    $button.addEventListener('click', (e) => {
        simplepicker.open();
    });

    // $eventLog.innerHTML += '\n\n';
    simplepicker.on('submit', (date, readableDate) => {
        $eventLog.innerHTML = readableDate + '\n';
    });

});



jQuery('.redo').click(function() {
    jQuery('.success').toggle();
});


jQuery('.left-side-button').on('click', function() {
    // alert('done');
    $this = jQuery(this);
    $nav = jQuery('.left-side');
    //$nav.fadeToggle("fast", function() {
    //  $nav.slideLeft('250');
//  });
    
    $nav.toggleClass('active');

});








function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            jQuery('#imagePreview').css('background-image', 'url('+e.target.result +')');
            jQuery('#imagePreview').hide();
            jQuery('#imagePreview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
jQuery("#imageUpload").change(function() {
    readURL(this);
});