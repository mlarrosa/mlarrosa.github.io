<?php
  wp_head();
?>

<style>
    .wp-site-blocks {display:none;}
</style>

<?php 
  if(!defined( 'ABSPATH' ) ) {
    
  };
?>


<div class="container">


    <?php 

        include_once plugin_dir_path(__FILE__) . 'includes/view-parts/left-nav.php'; 
        wp_reset_postdata();


        $path = preg_replace('/wp-content.*$/','',__DIR__);

        require_once($path."wp-load.php");

               
        if( !function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php');
        }

        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
        require_once( ABSPATH . 'wp-admin/includes/admin.php' );



        $unique_profile_pic_name = $recruit_fullname = $recruit_email = $recruit_position = $recruit_mobile = $recruit_portfolio_url = $recruit_github_url = $recruit_behance_url = $recruit_notes = $recruit_resume_url = $recruit_profile_pic_url = '';

        if( isset($_POST['submitbtn']) ) :
    
            $profile_pic = $_FILES['recruit_profile_pic_url'];
            $recruit_resume_url = $_FILES['recruit_resume_url'];

            if($recruit_resume_url['type'] != "application/pdf" && $recruit_resume_url['type'] != "application/msword") {
                $valid_resume = false;
                $errors['invalid_resume'] = "Please upload a valid resume file";
            } else {
                $valid_resume = true;
                $time = date("d-m-Y")."-".time();
                $unique_resume_name = $time."-".$recruit_resume_url['name'];

                $overrides = array( 'test_form' => false);
                $resume_file = wp_handle_upload( $recruit_resume_url, $overrides );

            }



            if($profile_pic['type'] != "image/jpg" && $profile_pic['type'] != "image/jpeg" && $profile_pic['type'] != "image/png"){
                $valid_profile_pic = false;
                $errors['invalid_profile_pic'] = "Please upload a valid profile picture";
            } else {
                $valid_profile_pic = true;
                $time = date("d-m-Y")."-".time();
                $unique_profile_pic_name = $time."-".$profile_pic['name'];


                $overrides = array( 'test_form' => false);
                $profile_pic_file = wp_handle_upload( $profile_pic, $overrides );
                        
            };


            $site_url = site_url();
            
            $recruit_fullname = isset($_POST['recruit_fullname']) ? $_POST['recruit_fullname'] : false;
            $recruit_email = isset($_POST['recruit_email']) ? $_POST['recruit_email'] : false;
            $recruit_position = isset($_POST['recruit_position']) ? $_POST['recruit_position'] : false;
            $recruit_mobile = isset($_POST['recruit_mobile']) ? $_POST['recruit_mobile'] : false;
            $recruit_portfolio_url = isset($_POST['recruit_portfolio_url']) ? $_POST['recruit_portfolio_url'] : false;
            $recruit_github_url = isset($_POST['recruit_github_url']) ? $_POST['recruit_github_url'] : false;
            $recruit_behance_url = isset($_POST['recruit_behance_url']) ? $_POST['recruit_behance_url'] : false;
            $recruit_notes = isset($_POST['recruit_notes']) ? $_POST['recruit_notes'] : false;
            $recruit_resume_url = $resume_file['url'];
            $recruit_profile_pic_url = $profile_pic_file['file'];

            $recruit_skype = isset($_POST['recruit_skype']) ? $_POST['recruit_skype'] : false;
            $bestcandidate;
            $recruit_interview_date = isset($_POST['recruit_interview_date']) && !empty(isset($_POST['recruit_interview_date'])) && strlen($_POST['recruit_interview_date']) != 0 ? $_POST['recruit_interview_date'] : NULL;

            
            $new_post = array(
                'post_title' => $recruit_fullname,
                'post_status' => 'publish',
                'post_type' => 'candidates'
            );
            $new_candidate_id = wp_insert_post($new_post);

            

            if( isset( $profile_pic_file['error'] ) || isset( $profile_pic_file['upload_error_handler'] ) ) {
                echo $profile_pic_file['error'];
            } else {
                $attachment = array(
                    'post_mime_type' => $profile_pic_file['type'],
                    'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $profile_pic_file['file'] ) ),
                    'post_content' => '',
                    'post_status' => 'inherit',
                    'guid' => $profile_pic_file['url'],
                    'post_parent' => $new_candidate_id,
                );
        
                // Insert attachment
                $attachment_id = wp_insert_attachment( $attachment, date('Y/m/') .  basename($profile_pic_file['url']) );
        
                // Set post thumbnail
                if( !has_post_thumbnail($new_candidate_id) ) {
                    set_post_thumbnail($new_candidate_id, $attachment_id);
                }
        
                // Update post meta
                if( $attachment_id ) {
                    $file_location = get_bloginfo('url') . '/wp-content/uploads' . date('Y/m/') . basename($profile_pic_file['url']);
                    update_post_meta($attachment_id, '_wp_attachment_metadata', serialize(array($file_location)));
                }
            }


            update_post_meta($new_candidate_id, 'recruit_portfolio_url', $recruit_portfolio_url);
            update_post_meta($new_candidate_id, 'recruit_github_url', $recruit_github_url);
            update_post_meta($new_candidate_id, 'recruit_behance_url', $recruit_behance_url);
            update_post_meta($new_candidate_id, 'recruit_fullname', $recruit_fullname);
            update_post_meta($new_candidate_id, 'recruit_position', $recruit_position);
            update_post_meta($new_candidate_id, 'recruit_resume_url', $recruit_resume_url);
            update_post_meta($new_candidate_id, 'recruit_email', $recruit_email);
            update_post_meta($new_candidate_id, 'recruit_skype', $recruit_skype);
            update_post_meta($new_candidate_id, 'recruit_mobile', $recruit_mobile);
            update_post_meta($new_candidate_id, 'recruit_notes', $recruit_notes);
            update_post_meta($new_candidate_id, 'recruit_interview_date', $recruit_interview_date);
            update_post_meta($new_candidate_id, 'recruit_best', "No");

        endif;

    ?>

    <div class="main">
        <div class="main-container">

            <form action="" role="form" method="POST" enctype="multipart/form-data">

                <div id="profile-container" class="row gutters-sm post-<?php echo get_the_ID();?>">

                    <div class="col-sm-12 col-md-6 col-lg-12 col-xl-5 mb-3">

                        <div id="schedule-date-text" class="editing-field">
                            <textarea id="recruit_interview_date" name="recruit_interview_date" class="event-log" readonly></textarea>
                            <a id="schedule-interview-button" href="#">Schedule Interview</a>
                        </div>

                        <div id="datepicker-container">
                            <div id="interview-datepicker" class="input-group">
                            </div>
                        </div>
                        
                        <div class="d-flex flex-column align-items-center text-center">
                            <div class="d-flex flex-column align-items-center text-center">
                                <div class="account-settings">
                                    <div class="user-profile">
                                    <div class="user-avatar">
                                        <div class="avatar-upload">
                                        <div class="avatar-edit">
                                            <input type="file" name="recruit_profile_pic_url" id="imageUpload" accept=".png, .jpg, .jpeg"/>
                                            <label for="imageUpload"></label>
                                        </div>
                                        <div class="avatar-preview">
                                            <div id="imagePreview" style="background-image: url(img/candidate-pic-placeholder.jpg);">
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card mt-5">

                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-globe mr-2 icon-inline"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>Portfolio</label>
                                    <span class="text-secondary"> 
                                        <input id="portfolio_url" name="recruit_portfolio_url" class="regular-text" type="text">
                                    </span>
                                </li>
                            
                            
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-github mr-2 icon-inline"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>Github</label>
                                    <span class="text-secondary"> 
                                        <input id="github_url" name="recruit_github_url" class="regular-text" type="text">
                                    </span>                            
                                </li>
                                                    
                            
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><i class="fa fa-behance-square behance-icon" style="color:#1a0dab;font-size:28px;margin-right:6px;"></i>Behance</label>
                                    <span class="text-secondary"> 
                                        <input id="behance_url" name="recruit_behance_url" class="regular-text" type="text">
                                    </span>  
                                </li>
                            </ul>

                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-12 col-xl-7">

                        <div class="card mb-3">
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                <label class="mb-0">Full Name</label>
                                </div>
                                <div class="col-sm-9 text-secondary">
                                    <input id="fullname" name="recruit_fullname" class="regular-text" type="text">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                    <label class="mb-0">Position</label>
                                </div>
                                <div class="col-sm-9 text-secondary">
                                    <input id="position" name="recruit_position" class="regular-text" type="text">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                    <label class="mb-0">Resume</label>
                                </div>
                                
                                <div class="col-sm-9 text-secondary">

                                    <p class="displayed-field">Not Uploaded</p>
                                    <input id="resume" name="recruit_resume_url" class="regular-text" type="file">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                    <label class="mb-0">Email</label>
                                </div>
                                
                                <div class="col-sm-9 text-secondary">
                                    <input id="email" name="recruit_email" class="regular-text" type="text">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                    <label class="mb-0">Skype</label>
                                </div>
                                
                                <div class="col-sm-9 text-secondary">
                                    <input id="skype" name="recruit_skype" class="regular-text" type="text">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                                    <label class="mb-0">Mobile</label>
                                </div>
                                
                                <div class="col-sm-9 text-secondary">

                                    <input id="mobile" name="recruit_mobile" class="regular-text" type="text">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div id="profile-note" class="form-group mt-3">
                                        <label for="exampleFormControlTextarea1"> Notes on this candidate:</label>

                                        <input id="recruit_notes" name="recruit_notes" class="regular-text" type="text">
                                    </div>
                                    <!-- Button HTML (to Trigger Modal) -->
                                    <input type="submit" name="submitbtn" id="add-candidate-button" value="Add Candidate">


                                    <!-- Modal HTML -->
                                    <div id="myModal" class="modal fade">
                                        <div class="modal-dialog modal-confirm">
                                            <div class="modal-content">
                                                <div class="modalbox success col-sm-8 col-md-6 col-lg-5 center animate">
                                                    <div class="icon">
                                                        <span class="fa fa-check"></span>
                                                    </div>
                                                    <!--/.icon-->
                                                    <h1>Success!</h1>
                                                    <p>The candidate has been deleted</p>
                                                </div>
                                                <!--/.success-->
                                                <div class="modal-header flex-column">
                                                    <div class="icon-box">
                                                        <i class="fa fa-exclamation-triangle"></i>
                                                    </div>            
                                                    <h4 class="modal-title w-100">Are you sure?</h4>  
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Do you really want to delete this candidate? <br/>This process cannot be undone.</p>
                                                </div>
                                                <div class="modal-footer justify-content-center">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                    <button id="delete-candidate-button" type="button" class="btn btn-danger redo"> Delete </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </form>

        </div>
    </div>

</div>




<?php 

wp_footer();
