<?php
  wp_head();
?>

<style>
    .wp-site-blocks {display:none;}
</style>

<?php 
  if(!defined( 'ABSPATH' ) ) {
    
  };
?>


<div class="container">


    <?php include_once plugin_dir_path(__FILE__) . 'includes/view-parts/left-nav.php'; ?>
    
    <div class="main">
        <div class="main-container">

            <div id="interviews-candidates-list">
                <?php
                    $args = array(
                        'post_type' => 'candidates',
                        'meta_query' => array(
                            array (
                                'key'     => 'recruit_interview_date',
                                'compare' => '!=',
                                'value' => NULL,
                            ),
                        ),
                    );
                    $candidates_interview_scheduled = new WP_Query( $args );                

                    if($candidates_interview_scheduled->have_posts()) : 
                        while($candidates_interview_scheduled->have_posts() ) : $candidates_interview_scheduled->the_post();
                ?>

                    <div class="users user-<?php echo get_the_ID();?>">
                        <ul class="default-ul">
                            <li class="status-read">
                                <div class="table">
                                    <div class="table-cell img-column">
                                        <a class="table-cell candidate-profile-link" href="<?php the_permalink();?>">
                                            <img class="img-circle" src="<?php echo get_the_post_thumbnail_url();?>" alt="Md.Pappu Miahn"  width="35" height="35">
                                        </a>
                                    </div>
                                    <div class="table-cell notification-info">
                                        <a class="table-cell candidate-profile-link" href="<?php the_permalink();?>">
                                            <div class="candidate-name"><?php the_title();?></div>
                                            <div class="candidate-position"><?php echo get_post_meta(get_the_ID(),'recruit_position', true);?></div>
                                        </a>
                                    </div> 
                                    <div class="table-cell">
                                        <div class="resume-download">
                                            <?php if( get_post_meta(get_the_ID(),'recruit_resume_url', true) ) : ?>
                                                <a href="<?php echo get_post_meta(get_the_ID(),'recruit_resume_url', true);?>" download >Download Resume</a>
                                            <?php else : ?>
                                                <p>Not Uploaded</p>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                    <div class="table-cell notification-info">
                                        <a class="table-cell candidate-profile-link" href="<?php the_permalink();?>">
                                            <div class="interview-date"><?php echo get_post_meta(get_the_ID(),'recruit_interview_date', true);?></div>
                                            <div class="candidate-phone">Candidate Phone</div>
                                            <div class="candidate-email">
                                                <a target="_blank" href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=<?php echo get_post_meta(get_the_ID(), 'recruit_email', true);?>">
                                                    <?php echo get_post_meta(get_the_ID(),'recruit_email', true);?>
                                                </a>
                                            </div>
                                        </a>
                                    </div> 
                                    <div class="table-cell"> 
                                        <button class="cancel-interview-button">Cancel Interview</button>
                                    </div>
                                </div>
                            </li>
                            <hr>
                        </ul>
                    </div>

                    <?php
                        endwhile;
                    endif;
                    ?>
            </div>
                

        </div>
    </div>  

</div>