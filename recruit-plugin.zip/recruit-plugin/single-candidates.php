<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

wp_head();



if(!defined('ABSPATH')) exit;


?>


<div class="container">

<?php 
    include_once plugin_dir_path(__FILE__) . 'includes/view-parts/left-nav.php'; 
    wp_reset_postdata();
?>

    <div class="main">
        <div class="main-container">

            <div id="profile-container" class="row gutters-sm post-<?php echo get_the_ID();?>">
                <div class="col-sm-12 col-md-6 col-lg-12 col-xl-5 mb-3">

                    <div class="card">
                        <?php if (get_post_meta($post->ID, 'recruit_interview_date', true) !== '' ) : ?>
                        <div id="confirmed-date-text"><strong>Confirmed Interview Date: </strong>
                            <p id="printed-text">
                                <?php echo get_post_meta($post->ID, 'recruit_interview_date', true); ?>
                            </p>
                        </div>
                        <?php elseif (get_post_meta($post->ID, 'recruit_interview_date', true) == '' ) : ?>
                        <div class="displayed-field" id="pending-date-text"><strong style="color:#c33838;">Pending Interview Date: </strong>
                            <p id="printed-text">
                                - Edit this candidate to set an interview date -
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div id="schedule-date-text" class="editing-field">
                        <textarea id="recruit_interview_date" name="recruit_interview_date" class="event-log" readonly></textarea>
                        <a id="schedule-interview-button" href="#">Schedule Interview</a>
                    </div>

                    <div id="datepicker-container">
                        <div id="interview-datepicker" class="input-group">
                        </div>
                    </div>
                    
                    <div class="d-flex flex-column align-items-center text-center">
                            <img id="candidate-profile-pic" src="<?php echo get_the_post_thumbnail_url();?>" alt="Admin" class="rounded-circle" width="150">
                            <div class="mt-3">
                                <h4 class="candidate-name mb-3"><?php echo get_post_meta($post->ID, 'recruit_fullname', true);?> </h4>
                                <?php if( get_post_meta($post->ID, 'recruit_best', true) == "No" ) : ?>
                                    <button id="add-as-best-candidate-button" class="btn btn-primary" > Mark as Best Candidate </button>
                                <?php elseif( get_post_meta($post->ID, 'recruit_best', true) == "Yes" ) : ?>
                                    <button id="remove-as-best-candidate-button" class="btn btn-danger"> Remove as Best Candidate </button>
                                <?php endif;?>
                            </div>
                        </div>

                    <div class="card mt-5">
                        <ul class="list-group list-group-flush">

                            <?php if(get_post_meta($post->ID, 'recruit_portfolio_url', true)) : ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-globe mr-2 icon-inline"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>Portfolio</label>
                                    <span class="text-secondary"> 
                                        <a class="displayed-field" target="_blank" href="//<?php echo get_post_meta($post->ID, 'recruit_portfolio_url', true);?>">
                                            <?php echo get_post_meta($post->ID, 'recruit_portfolio_url', true);?> 
                                        </a>
                                        <input id="portfolio_url" value="<?php echo get_post_meta($post->ID, 'recruit_portfolio_url', true);?>" name="recruit_portfolio_url" class="regular-text editing-field" type="text">
                                    </span>
                                </li>
                            <?php endif;?>
                            
                            <?php if(get_post_meta($post->ID, 'recruit_github_url', true)) : ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-github mr-2 icon-inline"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>Github</label>
                                    <span class="text-secondary"> 
                                        <a class="displayed-field" target="_blank" href="//<?php echo get_post_meta($post->ID, 'recruit_github_url', true);?>">
                                            <?php echo get_post_meta($post->ID, 'recruit_github_url', true);?> 
                                        </a>
                                        <input id="github_url" value="<?php echo get_post_meta($post->ID, 'recruit_github_url', true);?>" name="recruit_github_url" class="regular-text editing-field" type="text">
                                    </span>                            
                                </li>
                            <?php endif;?>
                                                    
                            <?php if(get_post_meta($post->ID, 'recruit_behance_url', true)) : ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <label class="mb-0"><i class="fa fa-behance-square behance-icon" style="color:#1a0dab;font-size:28px;margin-right:6px;"></i>Behance</label>
                                    <span class="text-secondary"> 
                                        <a class="displayed-field" target="_blank" href="//<?php echo get_post_meta($post->ID, 'recruit_behance_url', true);?>">
                                            <?php echo get_post_meta($post->ID, 'recruit_behance_url', true);?> 
                                        </a>
                                        <input id="behance_url" value="<?php echo get_post_meta($post->ID, 'recruit_behance_url', true);?>" name="recruit_behance_url" class="regular-text editing-field" type="text">
                                    </span>  
                                </li>
                            <?php endif;?>

                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-12 col-xl-7">
                    <div class="card mb-3">
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                          <label class="mb-0">Full Name</label>
                        </div>
                        <div class="col-sm-9 text-secondary">
                            <span class="displayed-field"><?php echo get_post_meta($post->ID, 'recruit_fullname', true);?></span>
                            <input id="fullname" value="<?php echo get_post_meta($post->ID, 'recruit_fullname', true);?>" name="recruit_fullname" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                            <label class="mb-0">Position</label>
                        </div>
                        <div class="col-sm-9 text-secondary">
                            <span class="displayed-field"><?php echo get_post_meta($post->ID, 'recruit_position', true);?></span>
                            <input id="position" value="<?php echo get_post_meta($post->ID, 'recruit_position', true);?>" name="recruit_position" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                            <label class="mb-0">Resume</label>
                        </div>
                        
                        <div class="col-sm-9 text-secondary">
                            <?php if( get_post_meta($post->ID, 'recruit_resume_url', true) ) :  ?>
                                <a class="displayed-field" href="<?php echo get_post_meta($post->ID, 'recruit_resume_url', true);?>" download >Download Resume</a>
                            <?php else: ?>
                                <p class="displayed-field">Not Uploaded</p>
                            <?php endif;?>
                            <input id="resume" value="<?php echo get_post_meta($post->ID, 'recruit_resume_url', true);?>" name="recruit_resume_url" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                            <label class="mb-0">Email</label>
                        </div>
                        
                        <div class="col-sm-9 text-secondary">
                            <a class="displayed-field" href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=<?php echo get_post_meta($post->ID, 'recruit_email', true);?>" target="_blank">
                                <?php echo get_post_meta($post->ID, 'recruit_email', true);?>
                            </a>
                            <input id="email" value="<?php echo get_post_meta($post->ID, 'recruit_email', true);?>" name="recruit_email" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                            <label class="mb-0">Skype</label>
                        </div>
                        
                        <div class="col-sm-9 text-secondary">
                            <a class="displayed-field" href="<?php echo get_post_meta($post->ID, 'recruit_skype', true);?>">
                                <?php echo get_post_meta($post->ID, 'recruit_skype', true);?>
                            </a>
                            <input id="skype" value="<?php echo get_post_meta($post->ID, 'recruit_skype', true);?>" name="recruit_skype" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3 col-md-12 col-lg-3 col-xl-3">
                            <label class="mb-0">Mobile</label>
                        </div>
                        
                        <div class="col-sm-9 text-secondary">
                            <span class="displayed-field"><?php echo get_post_meta($post->ID, 'recruit_mobile', true);?></span>
                            <input id="mobile" value="<?php echo get_post_meta($post->ID, 'recruit_mobile', true);?>" name="recruit_mobile" class="regular-text editing-field" type="text">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="profile-note" class="form-group mt-3">
                                <label for="exampleFormControlTextarea1"> Notes on this candidate:</label>
                                <p id="profile-note-text">
                                    <?php echo get_post_meta($post->ID, 'recruit_notes', true);?>
                                </p>
                                <input id="recruit_notes" value="<?php echo get_post_meta($post->ID, 'recruit_notes', true);?>" name="recruit_notes" class="regular-text editing-field" type="text">
                            </div>
                            <!-- Button HTML (to Trigger Modal) -->
                            <button id="edit-candidate-button">Edit Candidate</button>

                            <button id="update-candidate-button" type="submit" id="submit" name="submit" class="btn btn-primary load-button">
                                <span>Update Candidate</span>
                            </button>


                            <a id="open-modal-delete-candidate" href="#myModal" class="trigger-btn" data-toggle="modal">Delete Candidate</a>
                            <!-- Modal HTML -->
                            <div id="myModal" class="modal fade">
                                <div class="modal-dialog modal-confirm">
                                    <div class="modal-content">
                                        <div class="modalbox success col-sm-8 col-md-6 col-lg-5 center animate">
                                            <div class="icon">
                                                <span class="fa fa-check"></span>
                                            </div>
                                            <!--/.icon-->
                                            <h1>Success!</h1>
                                            <p>The candidate has been deleted</p>
                                        </div>
                                        <!--/.success-->
                                        <div class="modal-header flex-column">
                                            <div class="icon-box">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </div>            
                                            <h4 class="modal-title w-100">Are you sure?</h4>  
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Do you really want to delete this candidate? <br/>This process cannot be undone.</p>
                                        </div>
                                        <div class="modal-footer justify-content-center">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <button id="delete-candidate-button" type="button" class="btn btn-danger redo"> Delete </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>




<?php 

wp_footer();
