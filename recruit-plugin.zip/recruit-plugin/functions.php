<?php

if(!defined('ABSPATH')) exit;

/*
    Plugin Name: Recruit Plugin
    Description: Simple Recruitment Plugin
*/




include_once plugin_dir_path(__FILE__) . 'includes/plugin-menu/create-plugin-menus.php';
require_once plugin_dir_path(__FILE__) . 'includes/register-post-types.php';
require_once plugin_dir_path(__FILE__) . 'includes/add-metabox.php';



function register_styles_scripts() {

    wp_enqueue_style('poppins-font', 'https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light%7CPlayfair+Display:400&display=swap', [], '1.0', 'all');
    wp_enqueue_style('roboto-font', 'https://fonts.googleapis.com/css?family=Roboto:400,300', [], '1.0', 'all');
    wp_enqueue_style('bootsrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', [], '1.0', 'all');
    wp_enqueue_style('fontawesome-css', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css', [], '1.0', 'all');
    wp_enqueue_style('styles-css', plugin_dir_url( __FILE__ ) . 'styles.css', [], '1.0', 'all');

    wp_enqueue_script('jquery-js', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', [], '1.0', true);    
    wp_enqueue_script('popper-js', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', [], '1.0', true);
    wp_enqueue_script('bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', [], '1.0', true);
    wp_enqueue_script('bootstrap-bundle-js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js', [], '1.0', true);

    wp_enqueue_script('recruit-js', plugins_url( 'recruit.js', __FILE__ ), array('jquery'), '1.0', true);
    wp_enqueue_script('simplepicker-js', plugin_dir_url( __FILE__ ) . 'simplepicker.js', array('jquery'), '1.0', false);

    wp_localize_script('recruit-js', 'recruit_vars', ['ajaxurl'=> admin_url('admin-ajax.php') ]);

}

add_action('wp_enqueue_scripts', 'register_styles_scripts', 9999 );





function add_best_candidate() {
    $id_candidate = $_GET['id_candidate'];
    update_post_meta($id_candidate, 'recruit_best', "Yes");
    
}       
add_action('wp_ajax_nopriv_add_best_candidate', 'add_best_candidate', 20);
add_action('wp_ajax_add_best_candidate', 'add_best_candidate', 20);



function remove_best_candidate() {
    $id_candidate = $_GET['id_candidate'];
    update_post_meta($id_candidate, 'recruit_best', "No");
}       
add_action('wp_ajax_nopriv_remove_best_candidate', 'remove_best_candidate', 20);
add_action('wp_ajax_remove_best_candidate', 'remove_best_candidate', 20);



function delete_candidate() {
    $id_candidate = $_GET['id_candidate'];
    wp_delete_post($id_candidate, true);

    $redirect_url = site_url().'/dashboard';
    wp_send_json($redirect_url);

}       
add_action('wp_ajax_nopriv_delete_candidate', 'delete_candidate', 20);
add_action('wp_ajax_delete_candidate', 'delete_candidate', 20);



function edit_candidate() {
    $id_candidate = $_GET['id_candidate'];
    wp_send_json($id_candidate);
}       
add_action('wp_ajax_nopriv_edit_candidate', 'edit_candidate', 20);
add_action('wp_ajax_edit_candidate', 'edit_candidate', 20);



function cancel_interview() {
    $id_candidate = $_GET['id_candidate'];
    update_post_meta($id_candidate, 'recruit_interview_date', NULL);
}       
add_action('wp_ajax_nopriv_cancel_interview', 'cancel_interview', 20);
add_action('wp_ajax_cancel_interview', 'cancel_interview', 20);






function update_candidate() {
    $id_candidate = $_GET['id_candidate'];
    
    $portfolio_url = $_GET['candidate_portfolio_url'];
    $github_url = $_GET['candidate_github_url'];
    $behance_url = $_GET['candidate_behance_url'];
    $fullname = $_GET['candidate_fullname'];
    $position = $_GET['candidate_position'];
    $resume = $_GET['candidate_resume'];
    $email = $_GET['candidate_email'];
    $skype = $_GET['candidate_skype'];
    $mobile = $_GET['candidate_mobile'];
    $notes = $_GET['candidate_notes'];
    $interview_date = $_GET['candidate_interview_date'];
    $interview_date = preg_replace('/\s+/', ' ', $interview_date);

    update_post_meta($id_candidate, 'recruit_portfolio_url', $portfolio_url);
    update_post_meta($id_candidate, 'recruit_github_url', $github_url);
    update_post_meta($id_candidate, 'recruit_behance_url', $behance_url);
    update_post_meta($id_candidate, 'recruit_fullname', $fullname);
    update_post_meta($id_candidate, 'recruit_position', $position);
    update_post_meta($id_candidate, 'recruit_resume_url', $resume);
    update_post_meta($id_candidate, 'recruit_email', $email);
    update_post_meta($id_candidate, 'recruit_skype', $skype);
    update_post_meta($id_candidate, 'recruit_mobile', $mobile);
    update_post_meta($id_candidate, 'recruit_notes', $notes);
    update_post_meta($id_candidate, 'recruit_interview_date', $interview_date);

}       
add_action('wp_ajax_nopriv_update_candidate', 'update_candidate', 30);
add_action('wp_ajax_update_candidate', 'update_candidate', 30);






function add_new_candidate() {

    $portfolio_url = $_GET['candidate_portfolio_url'];
    $github_url = $_GET['candidate_github_url'];
    $behance_url = $_GET['candidate_behance_url'];
    $fullname = $_GET['candidate_fullname'];
    $position = $_GET['candidate_position'];
    $resume = $_GET['candidate_resume'];
    $email = $_GET['candidate_email'];
    $skype = $_GET['candidate_skype'];
    $mobile = $_GET['candidate_mobile'];
    $notes = $_GET['candidate_notes'];
    $interview_date = $_GET['candidate_interview_date'];
    $interview_date = preg_replace('/\s+/', ' ', $interview_date);
    


    $new_post = array(
        'post_title' => $fullname,
        'post_status' => 'publish',
        'post_type' => 'candidates'
    );
    $new_candidate_id = wp_insert_post($new_post);

    update_post_meta($new_candidate_id, 'recruit_portfolio_url', $portfolio_url);
    update_post_meta($new_candidate_id, 'recruit_github_url', $github_url);
    update_post_meta($new_candidate_id, 'recruit_behance_url', $behance_url);
    update_post_meta($new_candidate_id, 'recruit_fullname', $fullname);
    update_post_meta($new_candidate_id, 'recruit_position', $position);
    update_post_meta($new_candidate_id, 'recruit_resume_url', $resume);
    update_post_meta($new_candidate_id, 'recruit_email', $email);
    update_post_meta($new_candidate_id, 'recruit_skype', $skype);
    update_post_meta($new_candidate_id, 'recruit_mobile', $mobile);
    update_post_meta($new_candidate_id, 'recruit_notes', $notes);
    update_post_meta($new_candidate_id, 'recruit_interview_date', $interview_date);
    update_post_meta($new_candidate_id, 'recruit_best', "No");


}       
add_action('wp_ajax_nopriv_add_new_candidate', 'add_new_candidate', 30);
add_action('wp_ajax_add_new_candidate', 'add_new_candidate', 30);









function deactivate() {
    flush_rewrite_rules();
}


function activate() {

    function create_plugin_pages(){
        
        $plugin_pages = array('Dashboard','Interviews','NewCandidate');
    
        foreach($plugin_pages as $page_name) {
            if( get_page_by_title($page_name) == NULL ) {
                $new_page = array(
                    'post_title'    => $page_name,
                    'post_content'  => 'Add the shortcode ['.strtolower($page_name).'] to show the '.$page_name.' on this page.',
                    'post_status'   => 'publish',
                    'post_author'   => 1,
                    'page_template'  => 'template-parts/pages'.$page_name.'.php',
                    'post_type' => 'page'
                    );
                    wp_insert_post( $new_page );
            }
        }
    }

    create_plugin_pages();

}




function ur_theme_start_session()
{
    if (!session_id())
        session_start();
}
add_action("init", "ur_theme_start_session", 1);





// Este filtro suscribe el template de single.php y le asigna un template custom, dependiendo del post_type en el que estas parado. Lo estoy usando para tener un single-candidates.php, para mostrar el perfil del candidate
// El single-candidates.php  (candidates o cualquier otro post type) .... tiene que existir en el codigo, el archivo tiene que existir y tener codigo.

function override_single_template( $single_template ){
    global $post;

    $file = dirname(__FILE__) .'/single-'. $post->post_type .'.php';

    if( file_exists( $file ) ) $single_template = $file;

    return $single_template;
}

add_filter( 'single_template', 'override_single_template' );






    
function create_dashboard_page_shortcode() {
    include_once plugin_dir_path(__FILE__) . 'page-dashboard.php';
} 
add_shortcode( 'dashboard', 'create_dashboard_page_shortcode' );


    
function create_interviews_page_shortcode() {
    include_once plugin_dir_path(__FILE__) . 'page-interviews.php';
} 
add_shortcode( 'interviews', 'create_interviews_page_shortcode' );


    
function create_new_candidate_page_shortcode() {
    include_once plugin_dir_path(__FILE__) . 'page-new-candidate.php';
} 
add_shortcode( 'newcandidate', 'create_new_candidate_page_shortcode' );




register_activation_hook(__FILE__, 'activate');
register_deactivation_hook(__FILE__, 'deactivate');



